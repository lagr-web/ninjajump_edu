import World from "./World";
import * as THREE from "three";
import Light from "./Light";

class Ninja {
  constructor() {
    this.world = new World({
      showCameraPos: false,
      setCameraPos: [0.1, 0.7, 7],
      showGrid: false,
      showAxes: false,
      ambientLight: true,
      orbitControl: true,
      showFloor: true,
    }); //end world

    const geometryWall = new THREE.PlaneGeometry(30, 10);
    const materialWall = new THREE.MeshPhongMaterial({
      color: 0xe76c00,
      side: THREE.DoubleSide,
    });

    const wall = new THREE.Mesh(geometryWall, materialWall);
    wall.receiveShadow = true;
    wall.position.set(0, 5, -2);
    wall.rotation.x = 0;
    this.world.scene.add(wall);

    const ligthBox = new THREE.BoxGeometry(0.5, 0.5, 0.5);
    const ligtMaterial = new THREE.MeshNormalMaterial();

    const ligthMesh = new THREE.Mesh(ligthBox, ligtMaterial);
    ligthMesh.visible = false;
    ligthMesh.position.set(0, 0.5, 2.5);
    this.world.scene.add(ligthMesh);

    new Light(this.world, ligthMesh);

    this.world.renderer.setAnimationLoop((time) => this.myAnimation(time));
    //this.clock = new THREE.Clock();
  } //end function

  myAnimation(time) {
    this.world.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.world.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    //this.world.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.world.renderer.render(this.world.scene, this.world.camera);
  }
}

export default Ninja;
