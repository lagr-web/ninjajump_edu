import Ninja from "./Ninja";
import "../css/style.scss";

// **  IIFE: Immediately Invoked Function Expression  */

(function () {

   new Ninja();


})();
