import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { InteractionManager } from "three.interactive";

class World {
  
  constructor(settings) {

    console.log(settings);

    this.scene = new THREE.Scene();

    this.scene.background = new THREE.Color(0x000000);

    const size = 20;
    const divisions = 20;
    const gridHelper = new THREE.GridHelper(size, divisions);
    settings.showGrid && this.scene.add(gridHelper);

    const axesHelper = new THREE.AxesHelper(5);
    settings.showAxes && this.scene.add(axesHelper);

    this.camera = new THREE.PerspectiveCamera(
      50,
      window.innerWidth / window.innerHeight,
      0.1,
      150
    );

    this.camera.position.set(
      settings.setCameraPos[0],
      settings.setCameraPos[1],
      settings.setCameraPos[2]
    );

    this.camera.lookAt(this.scene.position);
    this.scene.add(this.camera);

    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      shadowMap: true,
      outputEncoding: THREE.sRGBEncoding,
    });

    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
   this.renderer.toneMapping = THREE.ReinhardToneMapping;
    this.renderer.setPixelRatio(window.devicePixelRatio);
    this.renderer.setSize(window.innerWidth, window.innerHeight);

    this.renderer.render(this.scene, this.camera);
    document.body.appendChild(this.renderer.domElement);

    this.interactionManager = new InteractionManager(
      this.renderer,
      this.camera,
      this.renderer.domElement
    );

    if (settings.orbitControl) {
      this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    }

    if (settings.showCameraPos && settings.orbitControl) {
      this.controls.addEventListener("change", (event) => {
        for (const key in this.controls.object.position) {
          console.log(
            `${key}:${Math.round(this.controls.object.position[key] * 10) / 10}`
          );
        }
      });
    } //end if

    const al = new THREE.AmbientLight(0xffffff, 0.5);
    settings.ambientLight && this.scene.add(al);

    const geometryFloor = new THREE.PlaneGeometry(25, 20);

    const materialFloor = new THREE.MeshPhongMaterial({
      color: 0xE76c00,
      side: THREE.DoubleSide,
    });

    const floor = new THREE.Mesh(geometryFloor, materialFloor);
    floor.receiveShadow = true;
    floor.rotation.x = Math.PI / 2;
    settings.showFloor && this.scene.add(floor);

    this.renderer.setAnimationLoop((time) => this.animation(time));

    window.addEventListener("resize", () =>
      this.onWindowResized(this.renderer, this.camera)
    );
  } //end function

  animation(time) {
    this.renderer.render(this.scene, this.camera);
  }

  onWindowResized() {
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
  }
}

export default World;
