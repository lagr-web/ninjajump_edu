import * as THREE from "three";

class Light {
  constructor(world, lightMesh) {

    const spotlightDown = new THREE.SpotLight(0xffffff, 400);
    spotlightDown.position.set(1.5, 20, 7.5);
    spotlightDown.angle = 0.314; //spreading
    spotlightDown.penumbra = 0.4; //blur in my world
    //spotLightDown.decay=2;
    spotlightDown.distance = 0;
    spotlightDown.castShadow = true;
    spotlightDown.target = lightMesh;
    //spotLightDown.shadow.bias = -0.0005;
    spotlightDown.shadow.mapSize.width = 2048; // default
    spotlightDown.shadow.mapSize.height = 2048; // default
    const slHelper = new THREE.SpotLightHelper(spotlightDown);
    world.scene.add(slHelper);

    world.scene.add(spotlightDown);

    world.scene.add(new THREE.HemisphereLight(0x443333, 0x111122));

    

  }
}

export default Light;
